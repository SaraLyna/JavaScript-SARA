# TP 3

# OUYAHIA Sara Lyna

## Mon travail
. installation des fichiers nécessaires au projet :

. production du bundle et exécution du projet :


. exécution dans : tp3/dist/index.html

. précisions sur le code :



## Travail réalisé
. par rapport au cahier des charges :
Création de la classe soit-dite qui regroupe d'autres classes ayant des caractéristiques communes : GameElement.js

Création des différentes classes d'objets qui héritent de GameElement: Arc.js, Carquois.js, Fleche.js, Oiseau.js, Cible.js

Codage de la classe game.js : afin de pouvoir jouer correctement à l'aide des méthodes : animate()...

Codage de la classe main.js : pour l'affichage des différents objets de game
